-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 23, 2024 at 09:25 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `healthcare`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `username` text NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`username`, `password`) VALUES
('Frank', ''),
('123', '123'),
('123', '123'),
('judge1', 'judge1');

-- --------------------------------------------------------

--
-- Table structure for table `medicine`
--

CREATE TABLE `medicine` (
  `name` text NOT NULL,
  `mindosage` text NOT NULL,
  `maxdosage` text NOT NULL,
  `expiration` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `medicine`
--

INSERT INTO `medicine` (`name`, `mindosage`, `maxdosage`, `expiration`) VALUES
('Paracetamol', '500 mg', '1000 mg', '2024-08-01'),
('Ibuprofen', '200 mg', '800 mg', '2023-11-15'),
('Amoxicillin', '250 mg', '1000 mg', '2024-04-30'),
('Aspirin', '75 mg', '300 mg', '2023-09-20'),
('Loratadine', '10 mg', '20 mg', '2024-06-10'),
('Omeprazole', '20 mg', '40 mg', '2025-01-05'),
('Simvastatin', '10 mg', '80 mg', '2023-12-15'),
('Metformin', '500 mg', '2000 mg', '2024-07-25'),
('Lisinopril', '10 mg', '40 mg', '2024-09-30'),
('Atorvastatin', '10 mg', '80 mg', '2024-03-12'),
('Levothyroxine', '25 mcg', '200 mcg', '2024-02-28'),
('Prednisone', '5 mg', '60 mg', '2023-11-01'),
('Metoprolol', '25 mg', '200 mg', '2024-08-15'),
('Sertraline', '25 mg', '200 mg', '2023-10-20'),
('Warfarin', '1 mg', '10 mg', '2023-12-31'),
('Cephalexin', '250 mg', '1000 mg', '2024-06-05'),
('Albuterol', '90 mcg', '180 mcg', '2024-04-15'),
('Ranitidine', '150 mg', '300 mg', '2023-11-30'),
('Doxycycline', '50 mg', '200 mg', '2024-07-10'),
('Gabapentin', '100 mg', '800 mg', '2023-09-25');

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `userid` text NOT NULL,
  `diagnosis` text NOT NULL,
  `name` text NOT NULL,
  `age` text NOT NULL,
  `gender` text NOT NULL,
  `address` text NOT NULL,
  `appointment` text NOT NULL,
  `medication` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`userid`, `diagnosis`, `name`, `age`, `gender`, `address`, `appointment`, `medication`) VALUES
('p4', 'Common', 'Pedro Reyes', '30', 'Male', '789 Elm St, Benito Soliven, Isabela', '2024-06-20', 'Paracetamol'),
('p5', 'Influenza', 'Ana Garcia', '25', 'Female', '111 Pine St, Burgos, Isabela', '2024-07-10', 'Ibuprofen'),
('p6', 'Allergic Rhinitis', 'Jose Lim', '35', 'Male', '222 Maple St, Cabagan, Isabela', '2024-07-05', 'Cetirizine'),
('p7', 'Gastritis', 'Carmen Rivera', '50', 'Female', '333 Birch St, Cauayan City, Isabela', '2024-06-25', 'Omeprazole'),
('p8', 'Migraine', 'Ramon Cruz', '45', 'Male', '444 Cedar St, Dinapigue, Isabela', '2024-06-18', 'Sumatriptan'),
('p9', 'Bronchitis', 'Luisa Reyes', '28', 'Female', '555 Oak St, Divilacan, Isabela', '2024-07-15', 'Amoxicillin'),
('p10', 'Back Pain', 'Juanito Santos', '60', 'Male', '666 Elm St, Echague, Isabela', '2024-06-30', 'Ibuprofen'),
('p11', 'Anxiety', 'Marcela Lopez', '32', 'Female', '777 Pine St, Gamu, Isabela', '2024-07-08', 'Sertraline'),
('p12', 'Asthma', 'Pedro Del Rosario', '22', 'Male', '888 Maple St, Ilagan City, Isabela', '2024-06-22', 'Albuterol'),
('p13', 'Sinusitis', 'Maria Dela Cruz', '38', 'Female', '999 Birch St, Jones, Isabela', '2024-07-03', 'Cefuroxime'),
('p14', 'Arthritis', 'Josefina Santos', '70', 'Female', '101 Cedar St, Luna, Isabela', '2024-06-28', 'Ibuprofen'),
('p15', 'Urinary Tract Infection', 'Juan Santos', '42', 'Male', '202 Oak St, Maconacon, Isabela', '2024-07-12', 'Ciprofloxacin'),
('p16', 'Acid Reflux', 'Rosario Reyes', '48', 'Female', '303 Elm St, Mallig, Isabela', '2024-06-23', 'Pantoprazole'),
('p17', 'Hypothyroidism', 'Emilio Garcia', '55', 'Male', '404 Pine St, Naguilian, Isabela', '2024-07-06', 'Levothyroxine'),
('p18', 'Gout', 'Maria Rivera', '58', 'Female', '505 Oak St, Palanan, Isabela', '2024-06-19', 'Colchicine'),
('p19', 'Chronic Fatigue Syndrome', 'Juan Del Rosario', '37', 'Male', '606 Elm St, Quirino, Isabela', '2024-07-09', 'Modafinil'),
('p20', 'Osteoarthritis', 'Ana Santos', '65', 'Female', '707 Pine St, Ramon, Isabela', '2024-06-24', 'Celecoxib'),
('p21', 'Insomnia', 'Pedro Garcia', '27', 'Male', '808 Maple St, San Agustin, Isabela', '2024-07-07', 'Zolpidem'),
('p1', 'nag tatae', 'natoy', '56', 'lalake', 'san fermin cauayan city', '15/12/2024', 'mag buhot ng mabigat hahahahahah');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
